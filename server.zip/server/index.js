import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import OpenAI from 'openai';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());

// Initialize OpenAI API client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Routes
app.get('/', (req, res) => {
  res.send('GiftSage API is running');
});

app.post('/api/recommendations', async (req, res) => {
  try {
    const { recipient, relationship, age, occasion, interests, budget, preferences } = req.body;

    // Validate required inputs
    if (!relationship || !age || !occasion || !interests || !budget) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Create a prompt for the OpenAI API
    const prompt = `
      Generate 5 thoughtful gift recommendations for a ${age} year old ${relationship}.
      Occasion: ${occasion}
      Their interests include: ${interests.join(', ')}
      Budget range: ${budget} (in Indian Rupees)
      Additional preferences: ${preferences || 'None specified'}
      
      For each gift recommendation, provide:
      1. Gift name
      2. Short description
      3. Approximate price in Indian Rupees (₹)
      4. Why this would be a good gift for them
      
      Format the response as a JSON array with these fields: name, description, price, reasoning, and category.
      Price should be a numeric value in rupees without the ₹ symbol.
    `;

    // Call OpenAI API
    const completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: "You are a gift recommendation specialist focusing on the Indian market. Provide thoughtful, personalized gift suggestions within the specified budget in Indian Rupees." },
        { role: "user", content: prompt }
      ],
      temperature: 0.7,
      max_tokens: 1000,
      response_format: { type: "json_object" }
    });

    // Parse the response
    const responseText = completion.choices[0].message.content;
    const recommendations = JSON.parse(responseText);

    res.json(recommendations);
  } catch (error) {
    console.error('Error generating recommendations:', error);
    res.status(500).json({ error: 'Failed to generate recommendations', details: error.message });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});